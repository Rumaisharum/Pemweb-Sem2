<?php
require_once 'Controllers/Prodi.php';
$id = $_GET['id'];
$prodi->show('id');
?>
